module Lib where

someFunc :: IO ()
someFunc = putStrLn "someFunc"

-- >>> test
test :: Integer
test = 1
