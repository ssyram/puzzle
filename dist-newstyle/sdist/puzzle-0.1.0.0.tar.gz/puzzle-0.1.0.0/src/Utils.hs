module Utils where

{-| Take a slice from the given string

>>> slice 1 2 [1, 2, 3, 4, 5]
[2,3]

>>> slice 0 0 [1, 2, 3, 4, 5]
[1]
-}
slice :: Int -> Int -> [a] -> [a]
slice from to = take (to - from + 1) . drop from
