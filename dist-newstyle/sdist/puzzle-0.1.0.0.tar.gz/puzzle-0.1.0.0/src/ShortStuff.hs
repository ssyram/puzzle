{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE ScopedTypeVariables #-}
module ShortStuff where

import Debug.Trace
import Data.Maybe
import Utils
import Data.List as List
import Control.Monad.State.Lazy

import Data.Array

-- This file is about short stuff for one or just a few functions / supporting data type

-- =============== Median: Add Two Numbers ====================
-- https://leetcode.com/problems/add-two-numbers/

{- | A list that just contains [0 - 9] for each position

For example, NumberList [2, 3, 4] represents number 234

Speicial Note: NumberList with 0 in its head and it is not 0 is illed form
-}
newtype NumberList = NumberList [Int] deriving (Show)

-- The function to format the given list -- return a non-illed form of the list
formatNumberList (NumberList l) = undefined

matchLength :: (Num a1, Num a2) => [a2] -> [a1] -> ([a2], [a1])
matchLength l1 l2 =
  let lengthDiff = length l1 - length l2 in
  if lengthDiff > 0 then (l1, replicate lengthDiff 0 ++ l2)
  else (replicate lengthDiff 0 ++ l1, l2)

addNumberList :: NumberList -> NumberList -> NumberList
addNumberList (NumberList l1) (NumberList l2) =
  let (l1', l2') = matchLength l1 l2 in
  -- trace (show l1' ++ "; " ++ show l2') $ NumberList []
  let (res, addPos) = add l1' l2' in
  NumberList $ if addPos > 0 then addPos:res else res
  where
    addSinglePos x y =
      if x + y >= 10 then (x + y - 10, 1)
      else (x + y, 0)
    -- add [x] [y] = let (num, addPos) = addSinglePos x y in ([num], addPos)
    add []  []  = ([], 0)
    add (x:l1') (y:l2') =
      let (res, addPos) = add l1' l2' in
      let (posNum, newAddPos) = addSinglePos x (y + addPos) in
      (posNum:res, newAddPos)
    add _ _ = undefined

-- A reversed version of number list -- 1234 is represented by [4, 3, 2, 1]
newtype ReverseNumberList = ReverseNumberList [Int] deriving (Show)

matchLengthOfReverseNumberList :: (Num a1, Num a2) => [a2] -> [a1] -> ([a2], [a1])
matchLengthOfReverseNumberList l1 l2 =
  let ld = length l1 - length l2 in
  if ld > 0 then (l1, l2 ++ replicate ld 0)
  else (l1 ++ replicate ld 0, l2)

addReversedNumberList :: ReverseNumberList -> ReverseNumberList -> ReverseNumberList
addReversedNumberList (ReverseNumberList l1) (ReverseNumberList l2) =
  let (l1', l2') = matchLengthOfReverseNumberList l1 l2 in
  ReverseNumberList $ add l1' l2' 0
  where
    add [] [] n = [1 | n > 0]
    add (x:l1) (y:l2) n =
      if x + y + n >= 10 then (x+y+n-10):add l1 l2 1
      else (x+y+n):add l1 l2 0
    add _ _ _ = undefined


-- ================ Hard: Binary Median Search in Two Sorted Arrays ===========================
-- Given two sorted arrays, find the median of the merged array, but in log(m + n)

{-| The idea behind is simple: use binary search simultaneously in all two arrays

until the sum of the two array position reached half of the sum of their lengths
-}
-- findMedianInTwoSortedArrays :: Array Int Int -> Array Int Int -> Rational
-- findMedianInTwoSortedArrays a1 a2 =
--   let curPointer = (a1, m `div` 2) in
--   let ~(res, pointerA1, pointerA2) =
--         iter ((m + n) `div` 2) curPointer (Just $ m `div` 2) (findPlace a2 $ fromJust $ at a1 $ m `div` 2) in
--   if odd $ (m + n) `div` 2 then res
--   else
--     let x = case at a1 (pointerA1 + 1) of
--               Just x ->
--                 case at a2 (pointerA2 + 1) of
--                   Just x' -> if x > x' then x' else x
--                   Nothing -> x
--               Nothing -> fromJust $ at a2 (pointerA2 + 1)
--     in
--     (res + toRational x) / 2
--   where
--     m = let (max, min) = bounds a1 in max - min
--     n = let (max, min) = bounds a2 in max - min
--     findPlace a n = undefined
--     iter target = undefined
--     at :: (Num i, Ix i) => Array i e -> i -> e
--     at a pos =
--       let (max, min) = bounds a in a!(min + pos)
--       -- if min + pos > max then Nothing else Just $ a!(min + pos)

standardToArray :: [e] -> Array Int e
standardToArray lst = listArray (0, length lst - 1) lst

mergeSortedList :: Ord a => [a] -> [a] -> [a]
mergeSortedList (s:l1) (s':l2)
  | s > s' = s':mergeSortedList (s:l1) l2
  | otherwise = s:mergeSortedList l1 (s':l2)
mergeSortedList [] l2 = l2
mergeSortedList l1 [] = l1

standardFindMedianInTwoSortedArrays :: Array Int Int -> Array Int Int -> Rational
standardFindMedianInTwoSortedArrays a1 a2 =
  let lst = mergeSortedList (Data.Array.elems a1) (Data.Array.elems a2) in
  trace (show lst) $
  median $ listArray (0, length lst - 1) lst

at :: (Ix i, Num i) => Array i e -> i -> e
at a pos = let (min, _) = bounds a in a!(min + pos)

median :: (Integral a, Ix a, Real e) => Array a e -> Rational
median a =
  let (lb, ub) = bounds a in
  if even $ ub - lb + 1 then toRational (at a ((ub - lb + 1) `div` 2) + at a ((ub - lb + 1) `div` 2 - 1)) / 2
  else toRational (at a ((ub - lb + 1) `div` 2))

findMedianInTwoSortedArrays :: Array Int Int -> Array Int Int -> Rational
findMedianInTwoSortedArrays a1 a2
  | len a1 == 0 && len a2 == 0 = error "Invalid Input"
  | len a1 == 0 = median a2
  | len a2 == 0 = median a1
  | otherwise = findMedian a1 a2 (bounds a1) (bounds a2)
  where
    len a = let (lb, ub) = bounds a in ub - lb
    findMedian :: Array Int Int -> Array Int Int -> (Int, Int) -> (Int, Int) -> Rational
    findMedian a1 a2 (lb1, ub1) (lb2, ub2) =
      let a1Mid = (ub1 - lb1) `div` 2 + lb1 in
      let a2Pos = findPlace a2 (lb2, ub2) a1Mid in
      let sum = a1Mid + a2Pos in
      let tar = (len a1 + len a2) `div` 2 in
      if sum > tar then findMedian a2 a1 (lb2, a2Pos) (lb1, ub1)
      else if sum < tar then findMedian a2 a1 (a2Pos, ub2) (lb1, ub1)
      -- else ((a1, a1Mid), (a2, a2Pos))
      else
        let curRes = at a1 a1Mid in
        if even $ len a1 + len a2 then
          let another =
                let backA1 = at a1 $ a1Mid - 1 in
                let backA2 = at a2 $ a2Pos - 1 in
                if a1Mid == 0 then backA2
                else if a2Pos == 0 then backA1
                else min backA1 backA2
          in
          toRational (curRes + another) / 2
        else toRational curRes
      where
        findPlace a (lb, ub) tar
          | ub == lb = at a lb
          | ub < lb = error "Invalid Input: ub < lb"
          | otherwise =
              let cur = (ub - lb) `div` 2 + lb in
              let curVal = at a cur in
              if curVal < tar then findPlace a (cur, ub) tar
              else if curVal > tar then findPlace a (lb, cur) tar
              else cur


-- =================== Longest Palindrome O(n) =================

data LongestPalindromeResult a n =
    LongestPalindromeResult
    { mode :: String,
      rest :: [a],
      former :: [a],
      lowerBound :: n,
      curNode :: n,
      internalBound :: n,
      result :: [n] }

simplerLongestPalindrome :: (Eq a, Show a) => [a] -> (Int, [a])
simplerLongestPalindrome str =
  if null str then (0, []) else
  trace ("Length of AppendedStr: " ++ show (length appendedStr)) $
  decorateResult $ foldl foldFunc (initRes appendedStr) $ zip [0..] appendedStr
  where
    appendedStr = tail $ do { c <- str; [Nothing, Just c] }
    decorateResult res =
      let (maxId, maxRadius) =
            foldl1
            (\x y ->
              if snd x > snd y then x
              else if (snd y > snd x) || ((snd x == snd y) && isNothing (appendedStr !! fst x)) then y
              else x) $
            zip [0..] $ reverse $ result res
      in
      trace ("Here" ++ show (reverse $ result res)) $
      let rs = do { c <- slice (maxId - maxRadius) (maxId + maxRadius) appendedStr; maybe [] return c } in
      (length rs, rs)
    initRes str =
      LongestPalindromeResult {
        mode = "Search From Start",
        rest = str,
        former = [],
        lowerBound = 0,
        curNode = 0,
        internalBound = 0,
        result = []
      }
    foldFunc curRes newC
      | mode curRes == "Search From Start" =
        trace ("Start Seaching From Start, with: " ++ show newC) $
        let lengthForCurrentNode =
              getLongestPalindrome (drop (lowerBound curRes) (latter curRes))
                                   (drop (lowerBound curRes) (former curRes)) (lowerBound curRes) in
        let nextRes = addNewLength lengthForCurrentNode curRes in
        startSearchInternal nextRes
      | mode curRes == "Internal Search" =
        trace ("Start Seaching From Internal, with: " ++ show newC) $
        if curNode curRes > internalBound curRes then
          {- 
            BUG DETECTED: if ending this time of loop here, the pointer will move to the next place rather in the head of "rest res"
            bias will enlarge when time goes
          -}
          searchFromStart curRes else
        let !dtb = distanceToBound curRes in
        let !mr = mirrorRadius curRes in
        if mr > dtb then
          trace "mr > dtb" $
          let nextRes = addNewLength dtb curRes in searchNextInternal nextRes
        else if mr < dtb then
          trace "mr < dtb" $
          let nextRes = addNewLength mr curRes in searchNextInternal nextRes
        else
      {-
      BUG DETECTED: each time to end the loop here, the next loop will start rather than the current node, the bias will enlarge
      -}   startSeachingFromStartWithLowerBound mr curRes
      | otherwise = error "No Such Mode"
      where
        getLongestPalindrome :: (Eq a, Integral n) => [a] -> [a] -> n -> n
        getLongestPalindrome (x:xs) (y:ys) n = if x == y then getLongestPalindrome xs ys (n + 1) else n
        getLongestPalindrome []     _      n = n
        getLongestPalindrome _      []     n = n
        addNewLength n res =
          trace ("Call add length. Current result: " ++ show (result res) ++ "; with new append: " ++ show n) $
          res { result = n:result res }
        latter = tail . rest
        startSearchInternal res = res {
          mode = "Internal Search",
          curNode = 1,
          internalBound = case result res of { s:_ -> s; _ -> error "Impossible" },
          rest = tail $ rest res,
          former = head (rest res):former res
        }
        searchFromStart res = res { mode = "Search From Start", lowerBound = 0 }
        distanceToBound res = internalBound res - curNode res
        mirrorRadius res =
          trace ("In Mirror Radius" ++ show (result res) ++ show (curNode res) ++ "; bound = " ++ show (internalBound res)) $
          result res !! (2 * curNode res - 1)
        searchNextInternal res = res {
          curNode = curNode res + 1,
          rest = tail $ rest res,
          former = head (rest res):former res
        }
        startSeachingFromStartWithLowerBound lb res =
          trace ("Current Lower Bound = " ++ show (lowerBound res) ++ "; To update to: " ++ show lb) $
          res {
            mode = "Search From Start",
            lowerBound = lb
          }


longestPalindrome :: (Eq a, Show a) => [a] -> (Int, [a])
longestPalindrome str =
  if null str then (0, []) else
  let infoOfAppendedStr = compute [] appendedStr [] 0 in
  trace (show appendedStr) $
  getResultFrom infoOfAppendedStr
  where
    -- "abc" -> tail "|a|b|c" -> "a|b|c"
    appendedStr = tail $ do { c <- str; [Nothing, Just c] }
    getResultFrom infoOfAppendedStr =
      trace (show infoOfAppendedStr) $
      let (maxId, maxRadius) =
            foldl1
            (\x y ->
              if snd x > snd y then x
              else if (snd y > snd x) || ((snd x == snd y) && isNothing (appendedStr !! fst x)) then y
              else x) $
            zip [0..] infoOfAppendedStr
      in
      let rs = do { c <- slice (maxId - maxRadius) (maxId + maxRadius) appendedStr; maybe [] return c } in
      (length rs, rs)
    getLongestPalindrome :: (Eq a) => [a] -> [a] -> Int -> Int
    getLongestPalindrome (s:str) (s':preStk) n =
      if s == s' then getLongestPalindrome str preStk (n + 1) else n
    getLongestPalindrome _ [] n = n
    getLongestPalindrome [] _ n = n
    -- compute :: (Eq a) => [Int] -> [a] -> [a] -> Int -> [Int]
    compute curInfo str preStk lowerBound =
      case str of
        []   -> reverse curInfo
        _:ss ->
          trace ("DroppedStr = " ++ show (drop lowerBound str) ++ "; DroppedPreStk = " ++ show (drop lowerBound preStk)) $
          let nextRadius = getLongestPalindrome (drop lowerBound ss) (drop lowerBound preStk) lowerBound in
          -- trace ("Next Radius: " ++ show nextRadius) $
          let nextInfo = nextRadius:curInfo in
          computeInternal 1 nextRadius nextInfo str preStk
    -- computeInternal :: (Eq a) => Int -> Int -> [Int] -> [a] -> [a] -> [Int]
    computeInternal cur bound info str preStk =
      trace ("Cur = " ++ show cur ++ "; Bound = " ++ show bound ++ "; Info = " ++ show info ++ "; str = " ++ show str ++
      "; preStk = " ++ show preStk) $
      if cur > bound then
        trace "Cur > Bound" $
        let (str', preStk') = passOnTo str preStk (bound + 1) in compute info str' preStk' 0
      else
        let mirrorRadius = info !! (2 * cur - 1) in
        let distanceToBound = bound - cur in
        if mirrorRadius > distanceToBound then
          trace ("Trigger > " ++ show (distanceToBound:info)) $
          computeInternal (cur + 1) bound (distanceToBound:info) str preStk
        else if mirrorRadius < distanceToBound then
          trace "Trigger < " $
          computeInternal (cur + 1) bound (mirrorRadius:info) str preStk
        else
          trace ("Trigger == " ++ show cur) $
          let (str', preStk') = passOnTo str preStk cur in
          trace ("str' = " ++ show str' ++ "; preStk' = " ++ show preStk') $
          compute info str' preStk' distanceToBound
      where
        passOnTo :: [a] -> [a] -> Int -> ([a], [a])
        passOnTo str stk bound =
          if bound <= 0 then (str, stk)
          else case str of { s:str' -> passOnTo str' (s:stk) (bound - 1); [] -> error "Impossible" }

-- toPrint =
--   putStrLn $ do
--   c <- ['A' .. 'Z']
--   "\\def\\script" ++ [c] ++ "{\\mathcal{" ++ [c] ++ "}}\n"

-- ========================== Easy: find two numbers ===============================

-- | >>> findTwoIndices [2,7,11,15] 9
-- [(1,0)]
findTwoIndices :: (Enum b, Ord b, Num b, Num a, Eq a) => [a] -> a -> [(b, b)]
findTwoIndices lst target = [(i, j) | (i, x) <- zip [0..] lst, (j, y) <- zip [0..] lst, i > j, x + y == target]


-- ========================= Medium: easy find palindrome ===========================

{-| longest palindrome

>>> easyFindLongestPalindrome ""
(0,"")
-}
easyFindLongestPalindrome :: Eq a => [a] -> (Int, [a])
easyFindLongestPalindrome s =
  if null s then (0, []) else
  let insertedS = tail $ do { c <- s; [Nothing, Just c] } in
  getResult $
  fromJust $
  foldl foldFunc Nothing [(reverse $ take n insertedS, drop n insertedS) | n <- [0..length insertedS - 1]]
  where
    getResult (n, ~(x:xs)) =
      let lst = take n xs in
      let res = [tx | x <- reverse lst ++ [x] ++ lst, isJust x, let Just tx = x] in
      (length res, res)
    foldFunc Nothing (_, ~lst@(h:xs)) = return (0, lst)
    foldFunc tmpRes@(Just (oldRadius, _)) (preStk, ~lst@(h:xs)) =
      let radius = findRadius preStk xs in
      let trueRadius = if radius > 0 && isNothing (preStk !! (radius - 1)) then radius - 1 else radius in
      if oldRadius < trueRadius then return (trueRadius, lst) else tmpRes
      where
        findRadius stk tl =
          tfr stk tl 0
          where
            tfr [] _ n = n
            tfr _ [] n = n
            tfr (x:xs) (y:ys) n = if x == y then tfr xs ys $ n + 1 else n


-- ========================= 3 Sum ===============================

-- | Given a list of numbers, divide them into triples that sum up to 0

-- >>> simpleTripets [-1,0,1,2,-1,-4]
-- [(-1,-1,2),(-1,0,1)]
threeSum :: (Num c, Ord c) => [c] -> [(c, c, c)]
threeSum lst =
  unique
  [(a', b', c') |
   (i, a) <- zip [0 .. ] lst,
   (j, b) <- zip [0 .. ] lst,
   i > j,
   (k, c) <- zip [0 .. ] lst,
   j > k,
   a + b + c == 0,
   let [a', b', c'] = sort [a, b, c]]
   where
     unique :: (Ord n) => [n] -> [n]
     unique lst =
       uq $ sort lst
       where
         uq :: (Eq a) => [a] -> [a]
         uq (x:y:xs) = (if x == y then uq else (x:) . uq) (y:xs)
         uq lst      = lst

-- ====================== Closest 3 Sum ==========================

-- >>> closestThreeSum [0, 0, 0] 1
-- Just (0,1,2,0)
closestThreeSum :: (Num c, Enum c, Ord a, Ord c, Num a) => [a] -> a -> Maybe (c, c, c, a)
closestThreeSum lst target =
  case lst of
    -- if length is at least 3
    x:y:z:_ ->
      return $
      minimumBy (\(_, _, _, s1) (_, _, _, s2) -> compare (abs $ s1 - target) (abs $ s2 - target))
      [(i, j, k, sum) |
      (i, a) <- zip [0 .. ] lst,
      (j, b) <- zip [0 .. ] lst,
      i < j,
      (k, c) <- zip [0 .. ] lst,
      j < k,
      let sum = a + b + c]
    _ -> Nothing

testState :: State Int ()
testState =
  do
    plus1
    plus1
  where
    plus1 = do { n <- get; put $ n + 1}

-- >>> testRunState
-- 3
testRunState = execState testState 1

-- ====================== Medium: generate parentheses ======================

-- >>> generateParentheses 3
-- ["((()))","(()())","(())()","()(())","()()()"]
generateParentheses :: Integer -> [String]
generateParentheses n =
  if n <= 0 then [""] else
  gp 1 [["()"], [""]] [[""], ["()"]]
  where
    -- k is the length of lst
    gp :: Integer -> [[String]] -> [[String]] -> [String]
    gp k lst revLst =
      if k >= n then head lst else 
      let next :: [String] = do {
        -- xs and ys combines have the same size
        (xs, ys) <- zip lst revLst;
        ["(" ++ x ++ ")" ++ y | x <- xs, y <- ys]
      }
      in
      gp (k + 1) (next : lst) (revLst ++ [next])
      
